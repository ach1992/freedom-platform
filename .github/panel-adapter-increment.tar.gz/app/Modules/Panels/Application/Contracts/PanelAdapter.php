<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application\Contracts;

use App\Modules\Panels\Application\PanelAdapterSession;
use App\Modules\Panels\Application\PanelConnectionProbe;
use App\Modules\Panels\Application\PanelCreateRequest;
use App\Modules\Panels\Application\PanelMutationRequest;
use App\Modules\Panels\Application\PanelOperationResult;
use App\Modules\Panels\Application\PanelRemoteSearchResult;
use App\Modules\Panels\Application\PanelRemoteService;
use App\Modules\Panels\Application\PanelRemoteServiceExpectation;
use App\Modules\Panels\Application\PanelTargetDescriptor;
use App\Modules\Panels\Domain\PanelProviderType;

interface PanelAdapter
{
    public function providerType(): PanelProviderType;

    public function testConnection(PanelAdapterSession $session): PanelConnectionProbe;

    public function searchRemoteService(PanelAdapterSession $session, PanelRemoteServiceExpectation $expectation): PanelRemoteSearchResult;

    public function createService(PanelAdapterSession $session, PanelCreateRequest $request): PanelOperationResult;

    public function fetchService(PanelAdapterSession $session, string $remoteId): ?PanelRemoteService;

    public function mutateService(PanelAdapterSession $session, PanelMutationRequest $request): PanelOperationResult;

    /** @return list<PanelTargetDescriptor> */
    public function compatibleTargets(PanelAdapterSession $session): array;
}
