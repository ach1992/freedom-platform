<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application\Contracts;

use App\Modules\Panels\Application\PanelAdapterSession;
use App\Modules\Panels\Application\PanelConnectionProbe;
use App\Modules\Panels\Application\PanelCreateRequest;
use App\Modules\Panels\Application\PanelMutationRequest;
use App\Modules\Panels\Application\PanelOperationResult;
use App\Modules\Panels\Application\PanelRemoteSearchResult;
use App\Modules\Panels\Application\PanelRemoteService;
use App\Modules\Panels\Application\PanelRemoteServiceExpectation;
use App\Modules\Panels\Application\PanelTargetDescriptor;

interface PanelProviderGateway
{
    public function probe(PanelAdapterSession $session): PanelConnectionProbe;

    public function search(PanelAdapterSession $session, PanelRemoteServiceExpectation $expectation): PanelRemoteSearchResult;

    public function create(PanelAdapterSession $session, PanelCreateRequest $request): PanelOperationResult;

    public function fetch(PanelAdapterSession $session, string $remoteId): ?PanelRemoteService;

    public function mutate(PanelAdapterSession $session, PanelMutationRequest $request): PanelOperationResult;

    /** @return list<PanelTargetDescriptor> */
    public function targets(PanelAdapterSession $session): array;
}
