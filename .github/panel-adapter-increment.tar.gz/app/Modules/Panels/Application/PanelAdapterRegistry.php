<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

use App\Modules\Panels\Application\Contracts\PanelAdapter;
use App\Modules\Panels\Domain\PanelProviderType;
use InvalidArgumentException;

final class PanelAdapterRegistry
{
    /** @var array<string, PanelAdapter> */
    private array $adapters = [];

    /** @param iterable<PanelAdapter> $adapters */
    public function __construct(iterable $adapters)
    {
        foreach ($adapters as $adapter) {
            $key = $adapter->providerType()->value;
            if (isset($this->adapters[$key])) {
                throw new InvalidArgumentException('Duplicate panel adapter registration.');
            }
            $this->adapters[$key] = $adapter;
        }
    }

    public function for(PanelProviderType $provider): PanelAdapter
    {
        return $this->adapters[$provider->value]
            ?? throw new InvalidArgumentException('Panel adapter is not registered.');
    }
}
