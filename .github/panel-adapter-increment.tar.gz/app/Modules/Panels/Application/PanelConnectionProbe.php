<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

final readonly class PanelConnectionProbe
{
    /** @param list<string> $capabilities */
    public function __construct(
        public bool $healthy,
        public string $panelType,
        public string $version,
        public array $capabilities,
        public string $capabilitiesHash,
        public string $testedAt,
    ) {}
}
