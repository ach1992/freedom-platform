<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

use App\Modules\Panels\Application\Contracts\PanelAdapter;
use App\Modules\Panels\Domain\PanelOperationClass;
use App\Modules\Panels\Domain\RemoteIdentityDisposition;

final readonly class PanelCreateCoordinator
{
    public function __construct(private RemoteIdentityResolver $resolver) {}

    /** @requirement PRV-001 SEC-002 QUA-001 */
    public function createOrAdopt(PanelAdapter $adapter, PanelAdapterSession $session, PanelCreateRequest $request): PanelOperationResult
    {
        $before = $this->resolver->resolve(
            $request->expectation,
            $adapter->searchRemoteService($session, $request->expectation),
        );
        $terminal = $this->terminalResolution($before);
        if ($terminal !== null) {
            return $terminal;
        }

        $created = $adapter->createService($session, $request);
        if ($created->classification !== PanelOperationClass::UncertainRemoteResult) {
            return $created;
        }

        $after = $this->resolver->resolve(
            $request->expectation,
            $adapter->searchRemoteService($session, $request->expectation),
        );
        $resolved = $this->terminalResolution($after);
        if ($resolved !== null) {
            return $resolved;
        }

        return new PanelOperationResult(
            PanelOperationClass::UncertainRemoteResult,
            null,
            'remote_create_unresolved',
            'Remote create result is uncertain and requires manual review.',
        );
    }

    private function terminalResolution(RemoteIdentityResolution $resolution): ?PanelOperationResult
    {
        return match ($resolution->disposition) {
            RemoteIdentityDisposition::Absent => null,
            RemoteIdentityDisposition::Adopt => PanelOperationResult::success($resolution->service, true),
            RemoteIdentityDisposition::Conflict => new PanelOperationResult(
                PanelOperationClass::Conflict,
                $resolution->service,
                $resolution->reasonCode,
                'Remote identity conflicts with the expected service.',
            ),
            RemoteIdentityDisposition::ManualReview => new PanelOperationResult(
                PanelOperationClass::UncertainRemoteResult,
                null,
                $resolution->reasonCode,
                'Remote identity could not be established authoritatively.',
            ),
        };
    }
}
