<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

use InvalidArgumentException;

final readonly class PanelCreateRequest
{
    /** @param array<string, scalar|null> $providerPayload */
    public function __construct(
        public string $idempotencyKey,
        public PanelRemoteServiceExpectation $expectation,
        public array $providerPayload,
    ) {
        if (preg_match('/\A[a-zA-Z0-9:_.-]{16,191}\z/', $idempotencyKey) !== 1) {
            throw new InvalidArgumentException('Panel idempotency key is invalid.');
        }
    }
}
