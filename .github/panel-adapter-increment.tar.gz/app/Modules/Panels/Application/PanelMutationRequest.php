<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

use App\Modules\Panels\Domain\PanelMutationOperation;

final readonly class PanelMutationRequest
{
    /** @param array<string, scalar|null> $parameters */
    public function __construct(
        public string $remoteId,
        public PanelMutationOperation $operation,
        public array $parameters,
        public string $idempotencyKey,
    ) {}
}
