<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

use App\Modules\Panels\Domain\PanelOperationClass;

final readonly class PanelOperationResult
{
    public function __construct(
        public PanelOperationClass $classification,
        public ?PanelRemoteService $service,
        public string $code,
        public string $safeMessage,
        public bool $adopted = false,
    ) {}

    public static function success(PanelRemoteService $service, bool $adopted = false): self
    {
        return new self(PanelOperationClass::Succeeded, $service, $adopted ? 'remote_service_adopted' : 'remote_operation_succeeded', 'Remote operation succeeded.', $adopted);
    }
}
