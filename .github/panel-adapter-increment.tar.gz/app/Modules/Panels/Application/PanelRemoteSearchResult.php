<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

final readonly class PanelRemoteSearchResult
{
    /** @param list<PanelRemoteService> $matches */
    public function __construct(
        public bool $authoritativeAndComplete,
        public array $matches,
    ) {}
}
