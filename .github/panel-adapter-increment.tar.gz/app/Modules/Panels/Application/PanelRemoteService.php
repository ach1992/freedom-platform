<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

final readonly class PanelRemoteService
{
    /** @param list<string> $subscriptionLinks */
    public function __construct(
        public string $remoteId,
        public string $username,
        public string $attributesHash,
        public string $status,
        public int $usedBytes,
        public int $dataAllowanceBytes,
        public ?int $expiresAtUnix,
        public array $subscriptionLinks = [],
    ) {}
}
