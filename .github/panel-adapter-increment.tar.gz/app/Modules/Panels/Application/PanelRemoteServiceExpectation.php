<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

use InvalidArgumentException;

final readonly class PanelRemoteServiceExpectation
{
    public string $attributesHash;

    /** @param array<string, scalar|null> $attributes */
    public function __construct(
        public string $deterministicUsername,
        public ?string $expectedRemoteId,
        public array $attributes,
    ) {
        if (preg_match('/\A[a-zA-Z0-9_.-]{3,128}\z/', $deterministicUsername) !== 1) {
            throw new InvalidArgumentException('Deterministic panel username is invalid.');
        }
        if ($expectedRemoteId !== null && (trim($expectedRemoteId) === '' || mb_strlen($expectedRemoteId) > 255)) {
            throw new InvalidArgumentException('Expected remote identifier is invalid.');
        }

        $normalized = $attributes;
        ksort($normalized);
        $this->attributesHash = hash('sha256', json_encode($normalized, JSON_THROW_ON_ERROR));
    }
}
