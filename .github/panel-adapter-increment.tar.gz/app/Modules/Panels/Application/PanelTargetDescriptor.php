<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

final readonly class PanelTargetDescriptor
{
    /** @param list<string> $capabilities */
    public function __construct(
        public string $remoteId,
        public string $kind,
        public string $name,
        public array $capabilities,
    ) {}
}
