<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

use App\Modules\Panels\Domain\RemoteIdentityDisposition;

final readonly class RemoteIdentityResolution
{
    public function __construct(
        public RemoteIdentityDisposition $disposition,
        public ?PanelRemoteService $service,
        public string $reasonCode,
    ) {}
}
