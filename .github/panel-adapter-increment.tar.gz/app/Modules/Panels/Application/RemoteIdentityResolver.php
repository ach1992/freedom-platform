<?php

declare(strict_types=1);

namespace App\Modules\Panels\Application;

use App\Modules\Panels\Domain\RemoteIdentityDisposition;

final class RemoteIdentityResolver
{
    /** @requirement PRV-001 SEC-002 QUA-001 */
    public function resolve(PanelRemoteServiceExpectation $expectation, PanelRemoteSearchResult $search): RemoteIdentityResolution
    {
        if (! $search->authoritativeAndComplete) {
            return new RemoteIdentityResolution(RemoteIdentityDisposition::ManualReview, null, 'remote_search_incomplete');
        }

        $candidates = array_values(array_filter(
            $search->matches,
            static function (PanelRemoteService $service) use ($expectation): bool {
                if ($expectation->expectedRemoteId !== null) {
                    return hash_equals($expectation->expectedRemoteId, $service->remoteId);
                }

                return hash_equals($expectation->deterministicUsername, $service->username);
            },
        ));

        if ($candidates === []) {
            return new RemoteIdentityResolution(RemoteIdentityDisposition::Absent, null, 'remote_service_absent');
        }
        if (count($candidates) !== 1) {
            return new RemoteIdentityResolution(RemoteIdentityDisposition::Conflict, null, 'remote_identity_not_unique');
        }

        $service = $candidates[0];
        if (! hash_equals($expectation->attributesHash, $service->attributesHash)) {
            return new RemoteIdentityResolution(RemoteIdentityDisposition::Conflict, $service, 'remote_attributes_mismatch');
        }

        return new RemoteIdentityResolution(RemoteIdentityDisposition::Adopt, $service, 'remote_service_matches');
    }
}
