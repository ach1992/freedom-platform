<?php

declare(strict_types=1);

namespace App\Modules\Panels\Domain;

enum PanelMutationOperation: string
{
    case UpdateExpiry = 'update_expiry';
    case SetDataAllowance = 'set_data_allowance';
    case AddDataAllowance = 'add_data_allowance';
    case ResetUsage = 'reset_usage';
    case Suspend = 'suspend';
    case Activate = 'activate';
    case Delete = 'delete';
    case RegenerateSubscription = 'regenerate_subscription';
    case Synchronize = 'synchronize';
}
