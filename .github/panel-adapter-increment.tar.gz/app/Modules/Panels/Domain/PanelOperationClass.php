<?php

declare(strict_types=1);

namespace App\Modules\Panels\Domain;

enum PanelOperationClass: string
{
    case Succeeded = 'succeeded';
    case DefinitiveFailure = 'definitive_failure';
    case RetryableFailure = 'retryable_failure';
    case UncertainRemoteResult = 'uncertain_remote_result';
    case Conflict = 'conflict';
}
