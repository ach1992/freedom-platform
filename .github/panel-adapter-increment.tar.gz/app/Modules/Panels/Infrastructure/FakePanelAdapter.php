<?php

declare(strict_types=1);

namespace App\Modules\Panels\Infrastructure;

use App\Modules\Panels\Application\Contracts\PanelAdapter;
use App\Modules\Panels\Application\PanelAdapterSession;
use App\Modules\Panels\Application\PanelConnectionProbe;
use App\Modules\Panels\Application\PanelCreateRequest;
use App\Modules\Panels\Application\PanelMutationRequest;
use App\Modules\Panels\Application\PanelOperationResult;
use App\Modules\Panels\Application\PanelRemoteSearchResult;
use App\Modules\Panels\Application\PanelRemoteService;
use App\Modules\Panels\Application\PanelRemoteServiceExpectation;
use App\Modules\Panels\Application\PanelTargetDescriptor;
use App\Modules\Panels\Domain\PanelMutationOperation;
use App\Modules\Panels\Domain\PanelOperationClass;
use App\Modules\Panels\Domain\PanelProviderType;

final class FakePanelAdapter implements PanelAdapter
{
    /** @var array<string, PanelRemoteService> */
    private array $services = [];

    private bool $nextCreateIsUncertain = false;

    private bool $searchIsComplete = true;

    public function providerType(): PanelProviderType
    {
        return PanelProviderType::Fake;
    }

    public function testConnection(PanelAdapterSession $session): PanelConnectionProbe
    {
        $capabilities = array_map(static fn (PanelMutationOperation $operation): string => $operation->value, PanelMutationOperation::cases());
        $capabilities[] = 'create_service';
        $capabilities[] = 'find_by_remote_id';
        $capabilities[] = 'find_by_username';
        sort($capabilities);

        return new PanelConnectionProbe(true, 'fake', '1.0.0', $capabilities, hash('sha256', implode('|', $capabilities)), gmdate('Y-m-d\TH:i:s\Z'));
    }

    public function searchRemoteService(PanelAdapterSession $session, PanelRemoteServiceExpectation $expectation): PanelRemoteSearchResult
    {
        $matches = array_values(array_filter(
            $this->services,
            static fn (PanelRemoteService $service): bool => ($expectation->expectedRemoteId !== null && $service->remoteId === $expectation->expectedRemoteId)
                || $service->username === $expectation->deterministicUsername,
        ));

        return new PanelRemoteSearchResult($this->searchIsComplete, $matches);
    }

    public function createService(PanelAdapterSession $session, PanelCreateRequest $request): PanelOperationResult
    {
        $remoteId = 'fake-'.substr(hash('sha256', $request->idempotencyKey), 0, 24);
        $existing = $this->services[$remoteId] ?? null;
        if ($existing !== null) {
            return hash_equals($existing->attributesHash, $request->expectation->attributesHash)
                ? PanelOperationResult::success($existing, true)
                : new PanelOperationResult(PanelOperationClass::Conflict, $existing, 'fake_remote_conflict', 'Fake remote service conflicts with the request.');
        }

        $service = new PanelRemoteService(
            $remoteId,
            $request->expectation->deterministicUsername,
            $request->expectation->attributesHash,
            'active',
            0,
            (int) ($request->expectation->attributes['data_allowance_bytes'] ?? 0),
            isset($request->expectation->attributes['expires_at_unix']) ? (int) $request->expectation->attributes['expires_at_unix'] : null,
            ['https://example.invalid/sub/'.rawurlencode($remoteId)],
        );
        $this->services[$remoteId] = $service;

        if ($this->nextCreateIsUncertain) {
            $this->nextCreateIsUncertain = false;

            return new PanelOperationResult(PanelOperationClass::UncertainRemoteResult, null, 'fake_timeout_after_create', 'Fake panel timed out after create.');
        }

        return PanelOperationResult::success($service);
    }

    public function fetchService(PanelAdapterSession $session, string $remoteId): ?PanelRemoteService
    {
        return $this->services[$remoteId] ?? null;
    }

    public function mutateService(PanelAdapterSession $session, PanelMutationRequest $request): PanelOperationResult
    {
        $service = $this->services[$request->remoteId] ?? null;
        if ($service === null) {
            return new PanelOperationResult(PanelOperationClass::DefinitiveFailure, null, 'fake_remote_not_found', 'Fake remote service was not found.');
        }

        if ($request->operation === PanelMutationOperation::Delete) {
            unset($this->services[$request->remoteId]);

            return PanelOperationResult::success($service);
        }

        return PanelOperationResult::success($service);
    }

    public function compatibleTargets(PanelAdapterSession $session): array
    {
        return [new PanelTargetDescriptor('fake-default', 'inbound', 'Fake default target', ['create_service'])];
    }

    public function makeNextCreateUncertain(): void
    {
        $this->nextCreateIsUncertain = true;
    }

    public function makeSearchIncomplete(): void
    {
        $this->searchIsComplete = false;
    }

    public function seed(PanelRemoteService $service): void
    {
        $this->services[$service->remoteId] = $service;
    }

    public function serviceCount(): int
    {
        return count($this->services);
    }
}
