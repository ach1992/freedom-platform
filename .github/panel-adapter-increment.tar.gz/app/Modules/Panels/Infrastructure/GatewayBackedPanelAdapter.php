<?php

declare(strict_types=1);

namespace App\Modules\Panels\Infrastructure;

use App\Modules\Panels\Application\Contracts\PanelAdapter;
use App\Modules\Panels\Application\Contracts\PanelProviderGateway;
use App\Modules\Panels\Application\PanelAdapterSession;
use App\Modules\Panels\Application\PanelConnectionProbe;
use App\Modules\Panels\Application\PanelCreateRequest;
use App\Modules\Panels\Application\PanelMutationRequest;
use App\Modules\Panels\Application\PanelOperationResult;
use App\Modules\Panels\Application\PanelRemoteSearchResult;
use App\Modules\Panels\Application\PanelRemoteService;
use App\Modules\Panels\Application\PanelRemoteServiceExpectation;
use App\Modules\Panels\Application\PanelTargetDescriptor;

abstract readonly class GatewayBackedPanelAdapter implements PanelAdapter
{
    public function __construct(private PanelProviderGateway $gateway) {}

    public function testConnection(PanelAdapterSession $session): PanelConnectionProbe
    {
        return $this->gateway->probe($session);
    }

    public function searchRemoteService(PanelAdapterSession $session, PanelRemoteServiceExpectation $expectation): PanelRemoteSearchResult
    {
        return $this->gateway->search($session, $expectation);
    }

    public function createService(PanelAdapterSession $session, PanelCreateRequest $request): PanelOperationResult
    {
        return $this->gateway->create($session, $request);
    }

    public function fetchService(PanelAdapterSession $session, string $remoteId): ?PanelRemoteService
    {
        return $this->gateway->fetch($session, $remoteId);
    }

    public function mutateService(PanelAdapterSession $session, PanelMutationRequest $request): PanelOperationResult
    {
        return $this->gateway->mutate($session, $request);
    }

    public function compatibleTargets(PanelAdapterSession $session): array
    {
        return $this->gateway->targets($session);
    }
}
