<?php

declare(strict_types=1);

namespace App\Modules\Panels\Infrastructure;

use App\Modules\Panels\Application\Contracts\MarzbanGateway;
use App\Modules\Panels\Domain\PanelProviderType;

final readonly class MarzbanAdapter extends GatewayBackedPanelAdapter
{
    public function __construct(MarzbanGateway $gateway)
    {
        parent::__construct($gateway);
    }

    public function providerType(): PanelProviderType
    {
        return PanelProviderType::Marzban;
    }
}
