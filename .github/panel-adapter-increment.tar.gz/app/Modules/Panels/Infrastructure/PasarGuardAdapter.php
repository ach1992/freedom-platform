<?php

declare(strict_types=1);

namespace App\Modules\Panels\Infrastructure;

use App\Modules\Panels\Application\Contracts\PasarGuardGateway;
use App\Modules\Panels\Domain\PanelProviderType;

final readonly class PasarGuardAdapter extends GatewayBackedPanelAdapter
{
    public function __construct(PasarGuardGateway $gateway)
    {
        parent::__construct($gateway);
    }

    public function providerType(): PanelProviderType
    {
        return PanelProviderType::PasarGuard;
    }
}
