<?php

declare(strict_types=1);

namespace App\Modules\Panels\Infrastructure;

use App\Modules\Panels\Application\Contracts\MarzbanGateway;
use App\Modules\Panels\Application\Contracts\PasarGuardGateway;
use App\Modules\Panels\Application\PanelAdapterSession;
use App\Modules\Panels\Application\PanelConnectionProbe;
use App\Modules\Panels\Application\PanelCreateRequest;
use App\Modules\Panels\Application\PanelMutationRequest;
use App\Modules\Panels\Application\PanelOperationResult;
use App\Modules\Panels\Application\PanelRemoteSearchResult;
use App\Modules\Panels\Application\PanelRemoteService;
use App\Modules\Panels\Application\PanelRemoteServiceExpectation;
use App\Modules\Panels\Domain\PanelOperationClass;

final class UnavailablePanelGateway implements MarzbanGateway, PasarGuardGateway
{
    public function probe(PanelAdapterSession $session): PanelConnectionProbe
    {
        return new PanelConnectionProbe(false, 'unconfigured', 'unknown', [], hash('sha256', 'unconfigured'), gmdate('Y-m-d\TH:i:s\Z'));
    }

    public function search(PanelAdapterSession $session, PanelRemoteServiceExpectation $expectation): PanelRemoteSearchResult
    {
        return new PanelRemoteSearchResult(false, []);
    }

    public function create(PanelAdapterSession $session, PanelCreateRequest $request): PanelOperationResult
    {
        return $this->unavailable();
    }

    public function fetch(PanelAdapterSession $session, string $remoteId): ?PanelRemoteService
    {
        return null;
    }

    public function mutate(PanelAdapterSession $session, PanelMutationRequest $request): PanelOperationResult
    {
        return $this->unavailable();
    }

    public function targets(PanelAdapterSession $session): array
    {
        return [];
    }

    private function unavailable(): PanelOperationResult
    {
        return new PanelOperationResult(
            PanelOperationClass::DefinitiveFailure,
            null,
            'panel_gateway_unconfigured',
            'Panel gateway is not configured.',
        );
    }
}
