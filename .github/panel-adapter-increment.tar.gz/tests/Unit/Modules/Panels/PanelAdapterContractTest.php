<?php

declare(strict_types=1);

namespace Tests\Unit\Modules\Panels;

use App\Modules\Panels\Application\PanelAdapterRegistry;
use App\Modules\Panels\Application\PanelAdapterSession;
use App\Modules\Panels\Application\PanelCreateCoordinator;
use App\Modules\Panels\Application\PanelCreateRequest;
use App\Modules\Panels\Application\PanelRemoteService;
use App\Modules\Panels\Application\PanelRemoteServiceExpectation;
use App\Modules\Panels\Application\RemoteIdentityResolver;
use App\Modules\Panels\Domain\PanelCredentials;
use App\Modules\Panels\Domain\PanelEndpoint;
use App\Modules\Panels\Domain\PanelOperationClass;
use App\Modules\Panels\Domain\PanelProviderType;
use App\Modules\Panels\Domain\TlsConfiguration;
use App\Modules\Panels\Domain\TlsPolicy;
use App\Modules\Panels\Infrastructure\FakePanelAdapter;
use PHPUnit\Framework\TestCase;

/** @requirement PRV-001 SEC-001 SEC-002 QUA-001 */
final class PanelAdapterContractTest extends TestCase
{
    public function test_uncertain_create_is_adopted_without_duplicate_remote_service(): void
    {
        $adapter = new FakePanelAdapter;
        $adapter->makeNextCreateUncertain();
        $expectation = $this->expectation();
        $result = (new PanelCreateCoordinator(new RemoteIdentityResolver))->createOrAdopt(
            $adapter,
            $this->session(),
            new PanelCreateRequest('panel:create:order-item:00000001', $expectation, []),
        );

        self::assertSame(PanelOperationClass::Succeeded, $result->classification);
        self::assertTrue($result->adopted);
        self::assertSame(1, $adapter->serviceCount());
    }

    public function test_mismatched_remote_identity_is_a_conflict_and_is_not_recreated(): void
    {
        $adapter = new FakePanelAdapter;
        $adapter->seed(new PanelRemoteService('remote-1', 'fp_user_001', hash('sha256', 'different'), 'active', 0, 1, null));
        $result = (new PanelCreateCoordinator(new RemoteIdentityResolver))->createOrAdopt(
            $adapter,
            $this->session(),
            new PanelCreateRequest('panel:create:order-item:00000002', $this->expectation(), []),
        );

        self::assertSame(PanelOperationClass::Conflict, $result->classification);
        self::assertSame(1, $adapter->serviceCount());
    }

    public function test_incomplete_remote_search_requires_review_and_blocks_create(): void
    {
        $adapter = new FakePanelAdapter;
        $adapter->makeSearchIncomplete();
        $result = (new PanelCreateCoordinator(new RemoteIdentityResolver))->createOrAdopt(
            $adapter,
            $this->session(),
            new PanelCreateRequest('panel:create:order-item:00000003', $this->expectation(), []),
        );

        self::assertSame(PanelOperationClass::UncertainRemoteResult, $result->classification);
        self::assertSame(0, $adapter->serviceCount());
    }

    public function test_registry_resolves_typed_adapter(): void
    {
        $adapter = new FakePanelAdapter;
        $registry = new PanelAdapterRegistry([$adapter]);

        self::assertSame($adapter, $registry->for(PanelProviderType::Fake));
    }

    private function expectation(): PanelRemoteServiceExpectation
    {
        return new PanelRemoteServiceExpectation('fp_user_001', null, [
            'data_allowance_bytes' => 1_073_741_824,
            'device_limit' => 1,
            'expires_at_unix' => 1_800_000_000,
            'profile_code' => 'vless-ws-tls',
        ]);
    }

    private function session(): PanelAdapterSession
    {
        return new PanelAdapterSession(
            PanelEndpoint::fromInput('https://panel.example.com'),
            PanelCredentials::fromInput(['username' => 'test', 'password' => 'secret']),
            new TlsConfiguration(TlsPolicy::SystemCa, null, null, null),
        );
    }
}
